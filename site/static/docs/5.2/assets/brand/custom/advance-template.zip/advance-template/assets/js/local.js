$("#tile-1 .nav-tabs a").click(function() {
  var position = $(this).parent().position();
  var width = $(this).parent().width();
    $("#tile-1 .slider").css({"left":+ position.left,"width":width});
});
var actWidth = $("#tile-1 .nav-tabs").find(".active").parent("li").width();
var actPosition = $("#tile-1 .nav-tabs .active").position();
$("#tile-1 .slider").css({"left":+ actPosition.left,"width": actWidth});

$("#tile-2 .nav-tabs a").click(function() {
    var position = $(this).parent().position();
    var width = $(this).parent().width();
      $("#tile-2 .slider").css({"left":+ position.left,"width":width});
  });
  var actWidth = $("#tile-2 .nav-tabs").find(".active").parent("li").width();
  var actPosition = $("#tile-2 .nav-tabs .active").position();
  $("#tile-2 .slider").css({"left":+ actPosition.left,"width": actWidth});


 
  $(document).ready(function () {
    $(".nameCellElli").on( "mouseenter", function() {
    var $this = $(this);
    if (this.offsetWidth < this.scrollWidth && !$this.attr('title')) {
      $this.tooltip({
        title: $this.text(),
        placement: "top",
        container:'body',
      });
      $this.tooltip('show');
    }
    });
  });




  // $(document).on('hover', ".nameCellElli", function () {
    
  // });