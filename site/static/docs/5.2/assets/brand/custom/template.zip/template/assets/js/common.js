// Global Js Start here
$(document).ready(function() {
	$(document).on("mousedown", ".btn-ripple" , function(e){     
		var target = e.target;
		var rect = target.getBoundingClientRect();
		var ripple = target.querySelector('.ripple');
		$(ripple).remove();
		ripple = document.createElement('span');
		ripple.className = 'ripple';
		ripple.style.height = ripple.style.width = Math.max(rect.width, rect.height) + 'px';
		target.appendChild(ripple);
		var top = e.pageY - rect.top - ripple.offsetHeight / 2 -  document.body.scrollTop;
		var left = e.pageX - rect.left - ripple.offsetWidth / 2 - document.body.scrollLeft;
		ripple.style.top = top + 'px';
		ripple.style.left = left + 'px';
		return false;
	});
	$(".nameCellElli").on( "mouseenter", function() {
		var $this = $(this);
		if (this.offsetWidth < this.scrollWidth && !$this.attr('title')) {
		  $this.tooltip({
			title: $this.text(),
			placement: "top",
			container:'body',
		  });
		  $this.tooltip('show');
		}
		});
	// User Profile Dropdown for animation
		$(".ds-hd-right>li").on("show.bs.dropdown", function (e) {
			$(this).find(".dropdown-menu").first().stop(true, true).show();
		});
		$(".ds-hd-right>li").on("hide.bs.dropdown", function (e) {
			$(this).find(".dropdown-menu").first().stop(true, true).hide();
		});
	// user role change on click
		$('.ds-hd-userole li').click(function() {
			$(".ds-hd-userole li").removeClass("active");
			$(this).addClass('active');
		});
		$('.ds-hd-userole li').click(function(){
			var txt = $(this).text();
			$('.ds-hd-emp').html(txt);
		});
	// Feedback Rating js
	/* 1. Action to perform on hover */
	$('#stars li').on('mouseover', function(){
		var onStar = parseInt($(this).data('value'), 10);
		$(this).parent().children('li.star').each(function(e){
			if (e < onStar) {
				$(this).addClass('hover');
			}
			else {
				$(this).removeClass('hover');
			}
		});
		}).on('mouseout', function(){
			$(this).parent().children('li.star').each(function(e){
				$(this).removeClass('hover');
			});
		});

	/* 2. Action to perform on click */
	$('#stars li').on('click', function(){
		var onStar = parseInt($(this).data('value'), 10);
		var stars = $(this).parent().children('li.star');
		for (i = 0; i < stars.length; i++) {
			$(stars[i]).removeClass('selected');
		}
		for (i = 0; i < onStar; i++) {
			$(stars[i]).addClass('selected');
		}
		var ratingValue = parseInt($('#stars li.selected').last().data('value'), 10);
		var msg = "";
		if (ratingValue == 1) {
			$("#star-color").addClass("belowA");
			msg = "Poor";
		}else if (ratingValue == 2) {
			$("#star-color").addClass("poor");
			msg = "Below Average";
		}else if (ratingValue == 3) {
			$("#star-color").addClass("average");
			msg = "Average";
		}else if (ratingValue == 4) {
			$("#star-color").addClass("good");
			msg = "Good";
		}else if (ratingValue == 5) {
			$("#star-color").addClass("excellent");
			msg = "Excellent";
		}
		responseMessage(msg);
        $("#star-color").removeClass("belowA, poor, average, good, excellent");
	});

	function responseMessage(msg) {
		$('.message').html("<span>" + msg + "</span>").css("opacity", "1");
	}
	$('#resetButton').click(function(){
		$('.star').removeClass("selected");
		$('.message').css('display', 'none');
	});
// Rating End
	setTimeout(function() {
		$('#success').modal('hide');
	}, 6000);
});

	// nav-item active js here
	var tabs = document.getElementsByClassName('nav-item');
	Array.prototype.forEach.call(tabs, function(tab) {
		tab.addEventListener('click', setActiveClass);
	});
	function setActiveClass(evt) {
		Array.prototype.forEach.call(tabs, function(tab) {
			tab.classList.remove('active');
		});
		evt.currentTarget.classList.add('active');
	}
// Global Js Ends here

//You can add your JS below here.............


